#pragma once

#include <vulkan/vulkan.h>

namespace vkt {
VkMetalSurfaceCreateInfoEXT CreateMetalSurfaceInfoEXT();
}  // namespace vkt
